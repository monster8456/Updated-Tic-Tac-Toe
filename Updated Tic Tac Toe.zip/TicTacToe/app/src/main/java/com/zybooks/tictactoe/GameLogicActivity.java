package com.zybooks.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

public class GameLogicActivity extends AppCompatActivity {

    //1 = O's, 2 = X's
    int player = 1;
    int GameState[] = {0,0,0,0,0,0,0,0,0};
    int [][] Winning = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    Boolean GameOn = true;
    Boolean isGameWon = false;

    //Shows whose turn it is
    String turn;
    String trackWinner;
    int plays;

    public void newGame() {

        player = 1; // Sets the player back to O
        plays = 0; // Sets the amount of plays back to 0
        GameOn = true; // Turns the game on
        turn = "X's Turn"; // Changes turn to tell users it's player 2's turn
        isGameWon = false;
        trackWinner = "";

         for (int i = 0; i < GameState.length; i++) {

            GameState[i] = 0; // Resets the clicked status of the squares
        }
    }

    // Method called when a square is clicked
    public void onTap(String tag) {
        plays++; // Increases the amount of plays that has occurred by 1

        if (GameOn && GameState[Integer.parseInt(tag)] == 0) { // Triggers if the game is on and the square tapped is empty

            GameState[Integer.parseInt(tag)] = player; // Sets the square tapped to player, to show that player hit the square and update the image accordingly

            if (player == 1) { // Switches the value of player to swap turns after a square is tapped
                player = 2;
                turn = "O's Turn";
            }

            else { // Switches the value of player to swap turns after a square is tapped
                player = 1;
                turn = "X's Turn";
            }

            for (int[] Winnings : Winning) {
                if (plays == 9) { // Triggers if the game was tied
                    turn = "CAT";

                    GameOn = false;
                }

                // Triggers if the game was won by a player and not tied
                else if (GameState[Winnings[0]] == GameState[Winnings[1]] && GameState[Winnings[1]] == GameState[Winnings[2]] && GameState[Winnings[0]] !=0) {

                    String winner = " ";

                    if (player == 1) { // If player 1 won, sets winner to O
                        winner = "O";
                        trackWinner = winner;
                        isGameWon = true;
                        GameOn = false; // Turns the game off
                        plays = 10;
                    }

                    else { // If player 2 won, sets winner to X
                        winner = "X";
                        trackWinner = winner;
                        isGameWon = true;
                        GameOn = false; // Turns the game off
                        plays = 10;
                    }
                }
            }
        }
    }

    public int getPlays() {
        return plays;
    }

    public int getPlayer() {
        return player;
    }

    public String getTurnText() {
        return turn;
    }

    public boolean getIsGameWon() {
        return isGameWon;
    }

    public String getWinner() {
        return trackWinner;
    }

    public int[] getGameState() {
        return GameState;
    }
}


