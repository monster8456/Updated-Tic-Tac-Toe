package com.zybooks.tictactoe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.ImageView;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button mNewGameToolbarButton;
    Button mQuitToolbarButton;
    TextView mTurnTextView;

    private GameLogicActivity gameLogic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQuitToolbarButton = findViewById(R.id.quitToolbarButton);
        mNewGameToolbarButton = findViewById(R.id.newGameToolbarButton);
        mTurnTextView = findViewById(R.id.turn_text_view);

        gameLogic = new GameLogicActivity();

        mNewGameToolbarButton.setOnClickListener(new View.OnClickListener() { // Resets the game when New Game button is clicked
            @Override
            public void onClick(View v) {
                int[] gotGameState = gameLogic.getGameState();
                gameLogic.newGame();

                String gotTurnText = gameLogic.getTurnText();
                mTurnTextView.setText(gotTurnText); // Sets TextView back to saying it's X's turn, the default starting turn

                for (int i = 0; i < gotGameState.length; i++) {

                    int squareTracker = getResources().getIdentifier("x" + i / 3 + i % 3, "id", getPackageName()); // Gets grid square ids
                    ImageView imageClearer = findViewById(squareTracker); // Sets that id to an ImageView
                    imageClearer.setImageDrawable(null); // Removes the image, x or o, from the square
                }
            }
        });

        mQuitToolbarButton.setOnClickListener(new View.OnClickListener() { // Quit button to quit the app if the user wants to
            @Override
            public void onClick(View v) {

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Quit Game")
                        .setMessage("Are you sure you want to quit?")

                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                    MainActivity.this.finish();
                                }
                        })

                        .setNegativeButton("No", null)
                        .show();
            }
        });
    }

    // Method called when a square is clicked
    public void tapped(View view) {
        ImageView img = (ImageView) view; // Sets the square to ImageView img
        String tag = img.getTag().toString(); // Gets tag to string to be used in arrays

        gameLogic.onTap(tag); // Calls the method to update the game

        int gotPlays = gameLogic.getPlays();
        boolean gotIsGameWon = gameLogic.getIsGameWon();
        String gotWinner = gameLogic.getWinner();
        int gotPlayer = gameLogic.getPlayer();
        String gotTurnText = gameLogic.getTurnText();

        if (gotPlays == 9) { // Triggers if game is tied
            mTurnTextView.setText("CAT");
        }

        else if (gotPlayer == 1 && gotIsGameWon && gotPlays <= 10) { // Triggers if game is won by player 1, O
            mTurnTextView.setText(gotWinner + " won!");
            img.setImageResource(R.drawable.o);
        }

        else if (gotPlayer == 2 && gotIsGameWon && gotPlays <= 10) { // Triggers if game is won by player 2, X
            mTurnTextView.setText(gotWinner + " won!");
            img.setImageResource(R.drawable.x);
        }

        if (gotPlayer == 1 && !gotIsGameWon) { // Triggers if turn is player 1's, or O
            mTurnTextView.setText(gotTurnText);
            img.setImageResource(R.drawable.o);
        }

        else if (gotPlayer == 2 && !gotIsGameWon) { // Triggers if turn is player 2's, or X
            mTurnTextView.setText(gotTurnText);
            img.setImageResource(R.drawable.x);
        }
    }
}
